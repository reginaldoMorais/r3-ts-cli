require('@babel/register')({});
require('./excludesExtensions');
require('./server');
