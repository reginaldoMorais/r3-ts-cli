require.extensions['.css'] = f => f;
require.extensions['.scss'] = f => f;
require.extensions['.ttf'] = f => f;
require.extensions['.png'] = f => f;
require.extensions['.jpg'] = f => f;
