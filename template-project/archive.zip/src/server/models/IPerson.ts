interface IPerson {
  name: string;
}

export default IPerson;
