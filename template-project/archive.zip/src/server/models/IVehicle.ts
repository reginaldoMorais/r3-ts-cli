interface IVehicle {
  name: string;
}

export default IVehicle;
