import esMessages from '../locales/pt_BR';

const BrLang = {
  messages: {
    ...esMessages
  },
  locale: 'pt-BR'
};
export default BrLang;
