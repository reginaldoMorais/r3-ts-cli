import enMessages from '../locales/fr';

const FrLang = {
  messages: {
    ...enMessages,
  },
  locale: 'fr',
};
export default FrLang;
