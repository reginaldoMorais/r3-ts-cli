import esMessages from '../locales/es';

const EsLang = {
  messages: {
    ...esMessages
  },
  locale: 'es'
};
export default EsLang;
