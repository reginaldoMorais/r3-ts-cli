import enMessages from '../locales/en';

const EnLang = {
  messages: {
    ...enMessages,
  },
  locale: 'en',
};
export default EnLang;
