export interface IOwnProps {
  title?: string;
  message?: string;
  type?: string;
}
