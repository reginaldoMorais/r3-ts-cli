import { ICharacter } from '../../../../server/models/Character';

export interface IOwnProps {
  character: ICharacter;
}
