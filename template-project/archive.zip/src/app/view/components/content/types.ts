import { ReactNode } from 'react';

export interface IOwnProps {
  fluid?: boolean;
  className?: string;
  children: ReactNode;
}
