export interface IOwnProps {
  isLoading: boolean;
}
