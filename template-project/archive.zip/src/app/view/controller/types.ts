import { ILocateState } from '../../redux/ducks/locate/types';

export interface IStateProps {
  locate: ILocateState;
}

export interface IDispatchProps {}

export interface IOwnProps { }
