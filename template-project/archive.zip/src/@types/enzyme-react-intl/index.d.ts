declare module 'enzyme-react-intl';
