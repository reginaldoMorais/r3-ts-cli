declare module 'react-scroll-up';
